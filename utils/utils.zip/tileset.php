<?php
require_once('classes/class.map.php');

function setTileByTerrain($terrain) {    
    
    switch($terrain) {
        case 'water':
        case 'swampwater':
        case 'deepwater':
          return setWaterTile($terrain);
        break;
    }

    $offset = getTilesetTerrainOffset($terrain);
    $terrainMapping = g('terrainMapping')[$terrain];

    if(isset($terrainMapping['special'])) {
        $special = (1 == rand(0,g('special')));
        if($special) {
            $special = $terrainMapping['special'];
            $offset += rand($special[0], $special[1]);
            return $offset;
        }
    }

    $terrain = $terrainMapping['terrain'];
    $offset += rand($terrain[0], $terrain[1]);
    return $offset;
}

function setWaterTile($terrain) {
    $offset = getTilesetTerrainOffset('water');
    if($terrain == 'swampwater') {
        $offset += 15;
    }
    if($terrain == 'deepwater') {
        $offset += 30;
    }

    $waterTiles = g('terrainMapping')['water']['terrain'];
    $waterTile = $waterTiles[rand(0,2)];

    return ($offset + $waterTile);
}



function getTilesetTerrainOffset($terrain) {
    $offset = 0;
    foreach(g('filesToInclude') as $_terrain => $_offset) {
        if($terrain == $_terrain) {
            return $offset * 5;
        }
        $offset += $_offset;
    }    
    return 0;
}

function offsetTest() {
    $terrain = g('terrainOrder');
    foreach($terrain as $ter) {
        echo $ter . ' ' . getTilesetTerrainOffset($ter) . ' ' . (getTilesetTerrainOffset($ter) / 5) . ' ' . setTileByTerrain($ter)  . '<br>' ;
    }

}



/** corners */
function getTransitions($data) {
    $terrain = g('terrainOrder');
    $map = new Map($data, $terrain);
    $transitions = $map->getTransitionLayer();
    for($y = 0; $y < $map->y; $y++ ) {
        for($x = 0; $x < $map->x; $x++) {
            foreach($transitions[$y][$x] as $terrain => $dest) {
                $transitions[$y][$x] = getTransitionGfx($dest[0], $terrain);
                exit;
            }            
            if(empty($transitions[$y][$x])) {
                $transitions[$y][$x] = -1;
            }
        }
    }  
    return $transitions;
}

function getTransitionGfx($dest, $terrain) {
    $terrainMapping = g('terrainMapping');  
    $pos = getTilesetTerrainOffset($terrain) + $terrainMapping['transitions'][$dest]; 
    return $pos;
}
